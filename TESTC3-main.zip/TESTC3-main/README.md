# TESTC3
# Xin chào! 👋

Nguyễn Ngọc Phong - mssv:2180605077 <br/>
Lê Như Tâm - mssv:2180605971





My name is Phong, một Lập trình viên Web và Đam mê mã nguồn mở.

![Profile Picture](https://placekitten.com/150/150)

## Về tôi

Mình là một lập trình viên đam mê sáng tạo và giải quyết vấn đề. Tôi thích thử nghiệm với các công nghệ mới và chia sẻ kiến thức của mình với cộng đồng.

## Kỹ năng

- HTML, CSS, JavaScript
- React, Vue
- Node.js, Express
- ...

## Dự án Nổi bật

Đang update! :)))

## Liên lạc
- Email: Phongkcr25251313@gmail.com
## Statistic
https://github.com/mynameisphongg


